@include('back.layouts.header')
@yield('content')
@include('back.layouts.footer')