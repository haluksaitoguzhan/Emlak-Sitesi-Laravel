@include('front.layouts.header')
@include('front.layouts.navbar')
@yield('content')
@include('front.layouts.footer')