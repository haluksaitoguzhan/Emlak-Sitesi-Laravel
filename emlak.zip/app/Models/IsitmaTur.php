<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class IsitmaTur extends Model
{
    protected $table = 'isitma_tur';
    protected $guarded=[];
}
