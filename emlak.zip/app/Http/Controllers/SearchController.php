<?php

namespace App\Http\Controllers;

use App\Models\Ilan;
use App\Models\Mahalle;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

use function PHPSTORM_META\type;

class SearchController extends Controller
{
    public function search(Request $request)
    {
        /*
        $stringHelper = new StringHelper();

        $offDayType = $request->offDayType;
        $rangeDatepicker = $request->date_range;
        $educationStatus = $request->education_status;
        $min_age = $request->min_age;
        $max_age = $request->max_age;
        $offDays = null;

        if(is_null($offDayType) && is_null($rangeDatepicker) && is_null($educationStatus) && is_null($min_age) && is_null($max_age)){
            return  redirect()->back()->with('error', 'Rapor oluşturmak için en az bir alan seçmelisiniz!');
        }

        if(is_null($offDayType) && is_null($rangeDatepicker) && is_null($educationStatus) && is_null($max_age) && !is_null($min_age)){
            $offDays = DB::table('users')
            ->where(DB::raw('TIMESTAMPDIFF(YEAR,users.birth_date,CURDATE())'),'>=' , $min_age )
            ->select('users.id','users.birth_date', 'users.name', 'users.surname')
            ->get();

        }
        if(is_null($offDayType) && is_null($rangeDatepicker) && is_null($educationStatus) && is_null($min_age) && !is_null($max_age)){
            $offDays = DB::table('users')
            ->where(DB::raw('TIMESTAMPDIFF(YEAR,users.birth_date,CURDATE())'),'<=' , $max_age )
            ->select('users.id','users.birth_date', 'users.name', 'users.surname')
            ->get();
        }

        if ($offDayType == 'all_off') {
            $offDays = DB::table('users')
                ->join('off_days', 'users.id', '=', 'off_days.user_id')
                ->select('users.id', 'users.name', 'users.surname', 'off_days.date_of_start', 'off_days.type', 'off_days.number_of_days', 'off_days.start_date', 'off_days.due_date')
                ->get();

            if ($rangeDatepicker) {
                $offDays = $this->getDateRange($stringHelper, $rangeDatepicker);
            }
        }

        if ($offDayType != null && is_numeric($offDayType)) {
            $offDays = OffDay::where('type', $offDayType)->get();
            if ($rangeDatepicker) {
                $offDays = $this->getDateRange($stringHelper, $rangeDatepicker, $offDayType);
            }
        }

        if ($educationStatus != null && is_numeric($educationStatus)) {
            // TODO
            $offDays = DB::table('users')
                ->join('off_days', 'users.id', '=', 'off_days.user_id')
                ->whereDate('off_days.start_date', '>=', Carbon::parse('2022-11-11')->format('Y-m-d'))
                ->whereDate('off_days.due_date', '<=', Carbon::parse('2022-11-18')->format('Y-m-d'))
                ->join('education', 'users.id', '=', 'education.user_id')
                ->where('education.education_status', $educationStatus)
                ->select('users.id', 'users.name', 'users.surname', 'off_days.date_of_start', 'off_days.type', 'off_days.start_date', 'off_days.due_date', 'off_days.number_of_days', 'education.education_status', 'education.degree', 'education.graduation_status', 'education.school_name', 'education.university_id', 'education.department_id')
                ->get();

            if (!$offDayType){
                    $offDays = DB::table('users')
                    ->join('education', 'users.id', '=', 'education.user_id')
                    ->where('education.education_status', $educationStatus)
                    ->select('users.id', 'users.name', 'users.surname', 'education.education_status', 'education.start_date', 'education.degree', 'education.graduation_status', 'education.school_name', 'education.university_id', 'education.department_id')
                    ->get();
            }

            if ($min_age && $max_age ) {
                $offDays = DB::table('users')
                    ->whereBetween(DB::raw('TIMESTAMPDIFF(YEAR,users.birth_date,CURDATE())'),[$min_age,$max_age])
                    ->join('off_days', 'users.id', '=', 'off_days.user_id')
                    ->whereDate('off_days.start_date', '>=', Carbon::parse('2022-11-11')->format('Y-m-d'))
                    ->whereDate('off_days.due_date', '<=', Carbon::parse('2022-11-18')->format('Y-m-d'))
                    ->join('education', 'users.id', '=', 'education.user_id')
                    ->where('education.education_status', $educationStatus)
                    ->select('users.id','users.birth_date', 'users.name', 'users.surname', 'off_days.date_of_start', 'off_days.type', 'off_days.start_date', 'off_days.due_date', 'off_days.number_of_days', 'education.education_status', 'education.degree', 'education.graduation_status', 'education.school_name', 'education.university_id', 'education.department_id')
                    ->get();
            }


        }else{

            if($offDayType != null && is_numeric($offDayType)){
                if ($min_age && $max_age){
                    $offDays = DB::table('users')
                        ->whereBetween(DB::raw('TIMESTAMPDIFF(YEAR,users.birth_date,CURDATE())'),[$min_age,$max_age])
                        ->join('off_days', 'users.id', '=', 'off_days.user_id')
                        ->whereDate('off_days.start_date', '>=', Carbon::parse('2022-11-11')->format('Y-m-d'))
                        ->whereDate('off_days.due_date', '<=', Carbon::parse('2022-11-18')->format('Y-m-d'))
                        ->select('users.id','users.birth_date', 'users.name', 'users.surname', 'off_days.date_of_start', 'off_days.type', 'off_days.start_date', 'off_days.due_date', 'off_days.number_of_days')
                        ->get();
                } else{
                    $offDays = DB::table('users')
                    ->whereBetween(DB::raw('TIMESTAMPDIFF(YEAR,users.birth_date,CURDATE())'),[$min_age,$max_age])

                    ->select('users.id','users.birth_date', 'users.name', 'users.surname')
                    ->get();

                    return $offDays;
                }// todo

            }

        }

         return view('super_admin.report', compact('offDays'));
         */
    }

    public function ilanlarimIcindeAra($selected){
        return $selected;
    }

    public function ilanAra(Request $request)
    {


        $ilanlar = DB::select("SELECT * FROM ilanlar,ilceler WHERE ilceler.il_id > ? and ilanlar.tip_id = ?", [$request->il,$request->tip]);

        foreach($ilanlar as $ilan){
            print_r($ilan);
            echo '<br><br><br><br><br>';
        }
        return count($ilanlar);
        $ilanlar = null;
        $il = $request->il;
        if($request->il==0 && $request->ilce==0 && $request->mah==0 && $request->tip==0 && $request->kimden==0 && $request->durum==0){
            return redirect()->route('tumIlanlar')->withErrors('Lütlen en az bir özellik seçiniz!');
        }
/*
        $ilanlar = DB::table('ilanlar')
        ->join('mahalleler', function ($join) {
            $join->on('ilanlar.mah_id', '=', 'mahalleler.id');
        })
        ->join('ilceler', function ($join) {
            $join->on('mahalleler.ilce_id', '=', 'ilceler.id');
        })
        ->Where(function($query) use($request) {
            $query->where('ilceler.il_id', '=', $request->il)
                  ->orWhere('ilceler.il_id', '>', 0);
        })
        ->where(function($query) use($request) {
            $query->where('ilceler.id', '=', $request->ilce)
                  ->orWhere('ilceler.id', '>', $request->ilce);
        })
        ->where(function($query) use($request) {
            $query->where('ilanlar.mah_id', '=', $request->mah)
                  ->orWhere('ilanlar.id', '>', $request->mah);
        })
        ->get();


        echo $ilanlar['ilceler']->il_id.' '.$ilanlar['ilceler']->id.' '.$ilanlar['ilceler']->id.'<br>';

*/












        $ilanlar=[];
        $adres=null;
        if($request->il!=0 ){// && $request->tip==0 && $request->kimden==0 && $request->durum==0
            
            if($request->ilce!=0 ){
                if($request->mah!=0){
                    $adres = Ilan::where('mah_id',$request->mah)
                    ->get();
                }else{
                    $adres =  Ilan::with('mahalle','Mahalle.ilce')
                    ->whereRelation('mahalle','ilce_id',$request->ilce)
                    ->get();
                }
            }else {
                $adres = Ilan::with('mahalle','Mahalle.ilce','Mahalle.ilce.il')
                ->whereRelation('Mahalle.ilce','il_id',$request->il)->set();
                //->get();
            }
            $ilanlar=$adres;

        }
        $tip=null;
        if($request->tip!=0){
            $tip = Ilan::where('tip_id',$request->tip)
            ->get();

            if($ilanlar!=null){
            $ilanlar=array_merge($ilanlar,$tip);
            }
            else{
                $ilanlar=$tip;
            }
        }

        $durum=null;
        if($request->durum!=0){
            $durum = Ilan::where('durum_id',$request->durum)
            ->get();
            
            if($ilanlar!=null){
                $ilanlar=array_merge($ilanlar,$durum);
                }
                else{
                    $ilanlar=$tip;
                }
        }

        $kimden=null;
        if($request->kimden!=0){
            $kimden =  Ilan::where('kimden_id',$request->kimden)
            ->get();
            
            if($ilanlar!=null){
                $ilanlar=array_merge($ilanlar,$kimden);
                }
                else{
                    $ilanlar=$tip;
                }
        }
        //return $ilanlar;
        return dd($ilanlar);


        /*$ilanlar = DB::table('ilanlar')
        ->join('mahalleler', function ($join) {
            $join->on('ilanlar.mah_id', '=', 'mahalleler.id');
        })
        ->join('ilceler', function ($join) {
            $join->on('mahalleler.ilce_id', '=', 'ilceler.id');
        })
        ->join('iller', function ($join) {
            $join->on('ilceler.il_id', '=', 'iller.id');
        })
         ->where('iller.id',$request->il)
        // ->where('ilceler.id',$request->ilce)
        // ->where('mahalleler.id',$request->mah)
       

        // ->where('tipler.id',$request->tip)
        // ->where('durum.id',$request->durum)
        // ->get();
        ->get();*/
        
        
        return dd($ilanlar);
        return redirect()->route('tumIlanlar')->withErrors('Lütlen en az bir özellik seçiniz!');
        //return response($ilanlar);
        
        



         // DB::table('ilanlar')
        // ->join('iller', 'users.id', '=', 'ilanlar.il_id')
        // ->whereDate('off_days.start_date', '>=', Carbon::parse('2022-11-11')->format('Y-m-d'))
        // ->whereDate('off_days.due_date', '<=', Carbon::parse('2022-11-18')->format('Y-m-d'))
        // ->join('education', 'users.id', '=', 'education.user_id')
        // ->where('education.education_status', $educationStatus)
        // ->select('users.id', 'users.name', 'users.surname', 'off_days.date_of_start', 'off_days.type', 'off_days.start_date', 'off_days.due_date', 'off_days.number_of_days', 'education.education_status', 'education.degree', 'education.graduation_status', 'education.school_name', 'education.university_id', 'education.department_id')
        // ->get();



        //$kelimeler = explode(" ", $request->key);

        
        /*
        // $ilanlar = Ilan::with('durum','tipler','mahalle','kimden','Mahalle.ilce','Mahalle.ilce.il')
        // ->where('status',1)
        // ->get();


        //MAHALLE
        // $sehir = DB::table('ilanlar')
        // ->join('mahalleler', function ($join) {
        //     $join->on('ilanlar.mah_id', '=', 'mahalleler.id');
        // })
        // ->where('mahalleler.id',$request->mah);

        //İLÇE
        $ilce = DB::table('mahalleler')
        ->join('ilceler', function ($join) {
            $join->on('mahalleler.ilce_id', '=', 'ilceler.id');
        })
        ->where('ilceler.id',$request->ilce);

        //ŞEHİR
        $mahalle = DB::table('ilceler')
        ->join('iller', function ($join) {
            $join->on('ilceler.il_id', '=', 'iller.id');
        })
        ->where('iller.id',$request->il);

        $ilanlar = DB::table('ilanlar')
        ->join('mahalleler', function ($join) {
            $join->on('ilanlar.mah_id', '=', 'mahalleler.id');
        })
        ->where('mahalleler.id',$request->mah)
        ->where('ilanlar.status',1)
        ->where('ilanlar.tip_id',$request->tip)
        ->where('ilanlar.durum_id',$request->durum)
        ->where('ilanlar.kimden_id',$request->kimden)
        ->union($ilce,$mahalle)
        ->get();


        dd($ilanlar);
        //return response($ilanlar);
        */

        /*
        $ilanlar = DB::table('ilanlar')
        ->where('ilanlar.status',1)
        ->join('mahalleler', function ($join) {
            $join->on('ilanlar.mah_id', '=', 'mahalleler.id');
        })
        ->join('ilceler', function ($join) {
            $join->on('mahalleler.ilce_id', '=', 'ilceler.id');
        })
        ->join('iller', function ($join) {
            $join->on('ilceler.il_id', '=', 'iller.id');
        })
        ->where(function ($query) {
            $query->where('iller.id', '=', 0)
                  ->orWhere('ilceler.id', '=', 0)
                  ->orWhere('mahalleler.id', '=', 0)
                  ->orWhere('ilanlar.durum_id', '=', 0)
                  ->orWhere('ilanlar.tip_id', '=', 0)
                  ->orWhere('ilanlar.kimden_id', '=', 0);
        })
        ->where('iller.id',$request->il)
        ->where('ilceler.id',$request->ilce)
        ->where('mahalleler.id',$request->mah)


        // ->where('tipler.id',$request->tip)
        // ->where('durum.id',$request->durum)
        // ->get();
        ->get();
        */

        //dd($request);    
       

        // ->where(function(Builder $query) { $query->where('mah_id', '')->orWhereNull('mah_id'); })
        // ->where('baslik', 'LIKE', "%$kelimeler[2]%")
        // ->where('aciklama', 'LIKE', "%$kelimeler[2]%")->get();
        //->orderby('created_at','DESC')->get();
        //->simplePaginate(6);
        //->get() ?? abort(403,'Böyle bir ilan bulunamadı!');
        
        //return view('front.grid',compact('ilanlar'));
    }
}
