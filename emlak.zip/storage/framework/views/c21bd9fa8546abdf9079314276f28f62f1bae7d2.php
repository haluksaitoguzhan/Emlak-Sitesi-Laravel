
<?php $__env->startSection('title','Emlak Sitesi'); ?>

<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
      <?php echo e(config('app.name', 'Laravel')); ?>

    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>




<!--/ Carousel Star /-->
<div class="intro intro-carousel">
  <div id="carousel" class="owl-carousel owl-theme">
    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($slider->resimler->first() != null): ?>
    <div class="carousel-item-a intro-item bg-image" style="background-image: url('<?php echo e(asset($slider->resimler->first()->resim)); ?>')">
      <div class="overlay overlay-a"></div>
      <div class="intro-content display-table">
        <div class="table-cell">
          <div class="container">
            <div class="row">
              <div class="col-lg-8">
                <div class="intro-body">
                  <p class="intro-title-top"><?php echo e($slider->mahalle->mahalle); ?>

                    <br> <?php echo e($slider->mah_id); ?>

                  </p>
                  <h1 class="intro-title mb-4">
                    <span class="color-b"><?php echo e($slider->adres); ?> </span> <?php echo e($slider->mahalle->mahalle); ?>

                    <br> <?php echo e($slider->baslik); ?>

                  </h1>
                  <p class="intro-subtitle intro-price">
                    <a href="#"><span class="price-a"><?php echo e($slider->durum->durum); ?> | <?php echo e($slider->fiyat); ?> ₺</span></a>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<!--/ Carousel end /-->

<!--/ resim sorguluyorum /-->

<!--/ Intro Single star /-->
<section class="intro-single">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-8">
        <div class="title-single-box">
          <h1 class="title-single"><a href="<?php echo e(route('ilanVer')); ?>">Hemen İlan Ver</a></h1>
          <span class="color-text-a">İlan vermek için tıklayın</span>
        </div>
      </div>
    </div>
  </div>
</section>
<!--/ Intro Single End /-->

<!--/ Property Star /-->
<section class="section-property section-t8">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="title-wrap d-flex justify-content-between">
          <div class="title-box">
            <h2 class="title-a">İlanlarım</h2>
          </div>
          <div class="title-link">
            <a href="<?php echo e(route('tumIlanlarim')); ?>">Tüm ilanlarım
              <span class="ion-ios-arrow-forward"></span>
            </a>
          </div>
        </div>
      </div>
    </div>

    <div id="property-carousel" class="owl-carousel owl-theme">
      <?php $__currentLoopData = $ilanlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($ilan->resimler->first() != null): ?>
      <div class="carousel-item-b">
        <div class="card-box-a card-shadow">
          <div class="img-box-a">
            <img src="<?php echo e(asset($ilan->resimler->first()->resim)); ?>" alt="" class="img-a img-fluid">
          </div>
          <div class="card-overlay">
            <div class="card-overlay-a-content">
              <div class="card-header-a">
                <h2 class="card-title-a">
                  <a href="<?php echo e(route('ilanlarim',$ilan->id)); ?>"><?php echo e($ilan->kimden->kimden); ?>

                    <br /> <?php echo e($ilan->baslik); ?></a>
                </h2>
              </div>
              <div class="card-body-a">
                <div class="price-box d-flex">
                  <span class="price-a"><?php echo e($ilan->durum->durum); ?> | <?php echo e($ilan->fiyat); ?> ₺</span>
                </div>
                <a href="<?php echo e(route('ilanlarim',$ilan->id)); ?>" class="link-a">İncelemek için tıklayın...
                  <span class="ion-ios-arrow-forward"></span>
                </a>
              </div>
              <div class="card-footer-a">
                <ul class="card-info d-flex justify-content-around">
                  <li>
                    <h4 class="card-info-title">Kimden</h4>
                    <span><?php echo e($ilan->kimden->kimden); ?></span>
                  </li>
                  <li>
                    <h4 class="card-info-title">Tip</h4>
                    <span><?php echo e($ilan->tipler->tip); ?></span>
                  </li>
                  <li>
                    <h4 class="card-info-title">Şehir</h4>
                    <span><?php echo e($ilan->mahalle->ilce->il->il); ?></span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<!--/ Property End /-->

<!--/ News Star /-->
<section class="section-news section-t8">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="title-wrap d-flex justify-content-between">
          <div class="title-box">
            <h2 class="title-a">Son İlanlar</h2>
          </div>
          <div class="title-link">
            <a href="<?php echo e(route('tumIlanlar')); ?>">Bütün ilanlar
              <span class="ion-ios-arrow-forward"></span>
            </a>
          </div>
        </div>
      </div>
    </div>
    <div id="new-carousel" class="owl-carousel owl-theme">

      <?php $__currentLoopData = $sonilanlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($ilan->resimler->first() != null): ?>
      <div class="carousel-item-c">
        <div class="card-box-b card-shadow news-box">
          <div class="img-box-b">
            <img src="<?php echo e(asset($ilan->resimler->first()->resim)); ?>" alt="" class="img-b img-fluid">
          </div>
          <div class="card-overlay">
            <div class="card-header-b">
              <div class="card-category-b">
                <a href="#" class="category-b"><?php echo e($ilan->tipler->tip); ?></a>
              </div>
              <div class="card-title-b">
                <h2 class="title-2">
                  <a href="<?php echo e(route('ilanlar',$ilan->id)); ?>">Sakın kaçırma!
                    <br> hemen ilana git</a>
                </h2>
              </div>
              <div class="card-date">
                <span class="date-b"><?php echo e($ilan->created_at->diffForHumans()); ?></span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</section>
<!--/ News End /-->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umut\Desktop\emlak\resources\views/front/homepage.blade.php ENDPATH**/ ?>