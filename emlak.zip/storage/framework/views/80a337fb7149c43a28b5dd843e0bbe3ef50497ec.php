<?php if(isset($ilan->resimler)): ?>
<label>Önceki Resimler | Silmek için işaretle:</label><br>
<div class="row">
    <?php $__currentLoopData = $ilan->resimler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilanresim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-4">
        <div class="1st">
            <span><span>
                    <a class="dropdown-item">
                        <div class="form-check form-check-inline">
                        <label for="checkbox">
                        <input class="form-check-input" type="checkbox" name="img[]" value="<?php echo e($ilanresim->id); ?>">
                        <div class="img-thumbnail rounded">
                        <img src="<?php echo e(asset($ilanresim->resim)); ?>"  width="180" height="110" alt="">
                        </label>
                        </div>
                        </div>
                    </a>
                </span></span>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- <?php $__currentLoopData = $ilan->resimler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilanresim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> -->
<!-- Logout Modal-->
<!-- <div class="modal fade" id="imgDelModal-<?php echo e($ilanresim->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Sil!</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Resmi silmek istediğinize emin misiniz?</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">İptal</button>
                    <a class="btn btn-primary" href="<?php echo e(route('guncelle_post',$ilan->id)); ?>">Sil</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->

<?php endif; ?><?php /**PATH C:\Users\umut\Desktop\emlak\resources\views/front/layouts/img_del_checkbox.blade.php ENDPATH**/ ?>