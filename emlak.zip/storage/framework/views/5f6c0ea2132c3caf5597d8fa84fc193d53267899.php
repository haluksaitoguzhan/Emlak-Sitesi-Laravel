
<?php $__env->startSection('title','Bekleyen İlanlar'); ?>
<?php $__env->startSection('content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><?php echo e($ilanlar->count()); ?> ilan mevcut.</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Resim</th>
                        <th>Başlık</th>
                        <th>Konum</th>
                        <th>Tip</th>
                        <th>Durum</th>
                        <th>Kimden</th>
                        <th>Fiyat</th>
                        <th>Alan</th>
                        <th>Oda</th>
                        <th>Isıtma</th>
                        <th>Kat</th>
                        <th>İletişim</th>
                        <th>Açıklama</th>
                        <th>Oluşturulma Tarihi</th>
                        <th>
                            <pre>         </pre>İncele
                        </th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ilanlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($ilan->resimler->first() != null): ?>
                        <td>
                            <img src="<?php echo e(asset($ilan->resimler->first()->resim)); ?>" width="200" height="100">
                        </td>
                        <?php else: ?>
                        <td>
                            <i class="bi bi-x"><span>Resim yok</span></i>
                        </td>
                        <?php endif; ?>
                        <!-- <td>System Architect</td> -->
                        <td><?php echo e($ilan->baslik); ?></td>
                        <td><?php echo e($ilan->adres); ?></td>
                        <td><?php echo e($ilan->tipler->tip); ?></td>
                        <td><?php echo e($ilan->durum->durum); ?></td>
                        <td><?php echo e($ilan->kimden->kimden); ?></td>
                        <td><?php echo e($ilan->fiyat); ?></td>
                        <td><?php echo e($ilan->alan); ?></td>
                        <td><?php if(isset($ilan->oda->oda_sayisi)): ?> <?php echo e($ilan->oda->oda_sayisi); ?> <?php else: ?> Boş <?php endif; ?></td>
                        <td><?php if(isset($ilan->isitmaTur->isitma_tur)): ?> <?php echo e($ilan->isitmaTur->isitma_tur); ?> <?php else: ?> Boş <?php endif; ?></td>
                        <td><?php if(isset( $ilan->katSayisi)): ?> <?php echo e($ilan->katSayisi); ?> <?php else: ?> Boş <?php endif; ?></td>
                        <td><?php echo e($ilan->tel); ?></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($ilan->aciklama,50,'...')); ?></td>
                        <td><?php echo e($ilan->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin_ilan_detay',$ilan->id)); ?>" title="İncele" class="btn btn-sm btn-success"><i class="fa fa-eye"></i> İncele </a>
                        </td>
                        <td>

                            <?php if(Request::segment(3) == 'bekleyen_ilanlar'): ?>
                            <a href="" title="Onayla" class="btn btn-sm btn-success" data-toggle="modal" data-target="#confirmModal"><i class="fa fa-check"></i> </a>
                            <?php endif; ?>
                            <a href="" title="Sil" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal"><i class="fa fa-trash"></i> </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umut\Desktop\emlak\resources\views/back/ilanlar.blade.php ENDPATH**/ ?>