
<?php $__env->startSection('title','Emlak Sitesi'); ?>

<?php $__env->startSection('content'); ?>
<!--/ Intro Single star /-->
<section class="intro-single">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-8">
          <div class="title-single-box">
            <h1 class="title-single"><?php echo e($ilan->baslik); ?></h1>
            <span class="color-text-a"><?php echo e($ilan->mahalle->ilce->il->il); ?> / <?php echo e($ilan->mahalle->ilce->ilce); ?> / <?php echo e($ilan->mahalle->mahalle); ?> / <?php echo e($ilan->adres); ?></span>
          </div>
        </div>
        <div class="col-md-12 col-lg-4">
          <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="<?php echo e(route('homepage')); ?>">Anasayfa</a>
              </li>
              <?php if(Request::segment(1) == 'ilanlarim'): ?>
              <li class="breadcrumb-item">
                <a href="<?php echo e(route('guncelle',$ilan->id)); ?>" >Düzenle</a>
              </li>
              <?php endif; ?>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </section>
  <!--/ Intro Single End /-->

  <!--/ Property Single Star /-->
  <section class="property-single nav-arrow-b">
    <div class="container">
      <div class="row">
        <div class="col-md-1 col-sm-12"></div>
        <div class="col-md-10 col-sm-12">
          <div id="property-single-carousel" class="owl-carousel owl-arrow gallery-property">
            
            <?php $__currentLoopData = $ilan->resimler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilanresim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="carousel-item-b">
                <img src="<?php echo e(asset($ilanresim->resim)); ?>" height="500" alt="">
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
          <div class="row justify-content-between">
            <div class="col-md-5 col-lg-4">
              <div class="property-price d-flex justify-content-center foo">
                <div class="card-header-c d-flex">
                  <div class="card-box-ico">
                    <span class="ion-money">₺</span>
                  </div>
                  <div class="card-title-c align-self-center">
                    <h5 class="title-c"><?php echo e($ilan->fiyat); ?></h5>
                  </div>
                </div>
              </div>
              <div class="property-summary">
                <div class="row">
                  <div class="col-sm-12">
                    <div class="title-box-d section-t4">
                      <h3 class="title-d">Detaylı Bilgi:</h3>
                    </div>
                  </div>
                </div>
                <div class="summary-list">
                  <ul class="list">
                    <li class="d-flex justify-content-between">
                      <strong>İlan Numarası:</strong>
                      <span><?php echo e($ilan->id); ?></span>
                    </li>
                    <li class="d-flex justify-content-between">
                      <strong>Konum:</strong>
                      <span><?php echo e($ilan->mahalle->mahalle); ?></span>
                    </li>
                    <li class="d-flex justify-content-between">
                      <strong>İlan Tipi:</strong>
                      <span><?php echo e($ilan->tipler->tip); ?></span>
                    </li>
                    <li class="d-flex justify-content-between">
                      <strong>Kimden:</strong>
                      <span><?php echo e($ilan->kimden->kimden); ?></span>
                    </li>
                    <li class="d-flex justify-content-between">
                      <strong>Durumu:</strong>
                      <span><?php echo e($ilan->durum->durum); ?></span>
                    </li>
                    <li class="d-flex justify-content-between">
                      <strong>Alan:</strong>
                      <span><?php echo e($ilan->alan); ?> m
                        <sup>2</sup>
                      </span>
                    </li>
                    <?php if(isset($ilan->oda->oda_sayisi)): ?>
                    <li class="d-flex justify-content-between">
                      <strong>Oda:</strong>
                      <span><?php echo e($ilan->oda->oda_sayisi); ?></span>
                    </li>
                    <?php endif; ?>
                    <?php if(isset($ilan->isitmaTur->isitma_tur)): ?>
                    <li class="d-flex justify-content-between">
                      <strong>Isıtma:</strong>
                      <span><?php echo e($ilan->isitmaTur->isitma_tur); ?></span>
                    </li>
                    <?php endif; ?>
                    <?php if(isset($ilan->katSayisi)): ?>
                    <li class="d-flex justify-content-between">
                      <strong>Kat Sayısı:</strong>
                      <span><?php echo e($ilan->katSayisi); ?></span>
                    </li>
                    <?php endif; ?>
                    <li class="d-flex justify-content-between">
                      <strong>İletişim:</strong>
                      <span><?php echo e($ilan->tel); ?></span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-7 col-lg-7 section-md-t3">
              <div class="row">
                <div class="col-sm-12">
                  <div class="title-box-d">
                    <h3 class="title-d"><?php echo e($ilan->baslik); ?></h3>
                  </div>
                </div>
              </div>
              <div class="property-description">
                <p class="description color-text-a">
                  <?php echo e($ilan->aciklama); ?>

                </p>
              </div>

            </div>
          </div>
        </div>
        <div class="col-md-1 col-sm-12"></div>
        
  </section>
  <!--/ Property Single End /-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umut\Desktop\emlak\resources\views/front/single.blade.php ENDPATH**/ ?>