
<?php $__env->startSection('title','İlan Detayı'); ?>
<?php $__env->startSection('content'); ?>


    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <!-- Slider Star -->
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <?php $__currentLoopData = $ilan->resimler; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ilanresim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($ilanresim->resim != null): ?>
                            <div class="carousel-item <?php if($ilan->resimler->first()->resim == $ilanresim->resim): ?> active <?php endif; ?>">
                                <img class="d-block w-100" src="<?php echo e(asset($ilanresim->resim)); ?>" alt="<?php echo e($ilanresim->resim); ?>" style="width: 250px; height: 550px">
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Önceki</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Sonraki</span>
                </a>
            </div>
            <!-- Slider end -->
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <!-- <thead> -->
                    <!-- <tbody> -->
                        <tr><th colspan="2">İlan Özellikleri</th></tr>
                        <tr><td><strong>Başlık</strong> </td><td><?php echo e($ilan->baslik); ?></td></tr>
                        <tr><td><strong>Konum</strong> </td><td><?php echo e($ilan->mahalle->mahalle); ?> / <?php echo e($ilan->adres); ?></td></tr>
                        <tr><td><strong>Tip</strong> </td><td><?php echo e($ilan->tipler->tip); ?></td></tr>
                        <tr><td><strong>Durum</strong> </td><td><?php echo e($ilan->durum->durum); ?></td></tr>
                        <tr><td><strong>Kimden</strong> </td><td><?php echo e($ilan->kimden->kimden); ?></td></tr>
                        <tr><td><strong>Fiyat</strong> </td> <td><?php echo e($ilan->fiyat); ?></td></tr>
                        <tr><td><strong>Alan</strong> </td><td><?php echo e($ilan->alan); ?></td></tr>
                        <tr><td><strong>Oda Sayısı</strong> </td><td><?php if(isset($ilan->oda->oda_sayisi)): ?> <?php echo e($ilan->oda->oda_sayisi); ?> <?php else: ?> Boş <?php endif; ?></td></tr>
                        <tr><td><strong>Isıtma Türü</strong> </td><td><?php if(isset($ilan->isitmaTur->isitma_tur)): ?> <?php echo e($ilan->isitmaTur->isitma_tur); ?> <?php else: ?> Boş <?php endif; ?></td></tr>
                        <tr><td><strong>Kat</strong> </td><td><?php if(isset( $ilan->katSayisi)): ?> <?php echo e($ilan->katSayisi); ?> <?php else: ?> Boş <?php endif; ?></td></tr>
                        <tr><td><strong>İletişim</strong> </td><td><?php echo e($ilan->tel); ?></td></tr>
                        <tr><td><strong>Oluşturulma Tarihi</strong> </td><td><?php echo e($ilan->created_at); ?></td></tr>
                        <tr><td><strong>Açıklama</strong> </td><td><?php echo e($ilan->aciklama); ?></td></tr>
                        <tr>   
                            <th colspan="2">
                            <?php if(Request::segment(3) == 'ilan_detay' && $ilan->status == 0): ?>
                                <a href="" title="Onayla" class="btn btn-sm btn-success" data-toggle="modal" data-target="#confirmModal"><i class="fa fa-check"></i> ONAYLA </a>
                            <?php endif; ?>
                                <a href="" title="Sil" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal"><i class="fa fa-trash"></i> SİL</a>
                            </th>
                        </tr>
                    <!-- </tbody> -->
                    <!-- </thead> -->
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
               
<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umut\Desktop\emlak\resources\views/back/ilandetay.blade.php ENDPATH**/ ?>