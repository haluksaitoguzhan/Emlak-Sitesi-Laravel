<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta name="description" content="Free Web tutorials">
  <meta name="keywords" content="HTML, CSS, JavaScript">
  <meta name="author" content="Haluk Sait">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="<?php echo e(asset('front')); ?>/img/favicon.png" rel="icon">
  <link href="<?php echo e(asset('front')); ?>/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="<?php echo e(asset('front')); ?>/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="<?php echo e(asset('front')); ?>/lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('front')); ?>/lib/animate/animate.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('front')); ?>/lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('front')); ?>/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="<?php echo e(asset('front')); ?>/css/style.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: EstateAgency
    Theme URL: https://bootstrapmade.com/real-estate-agency-bootstrap-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
  <?php echo $__env->yieldContent('js'); ?>
</head>
<body>

  <div class="click-closed"></div><?php /**PATH C:\Users\umut\Desktop\emlak sitesi\emlak\resources\views/front/layouts/header.blade.php ENDPATH**/ ?>