
<?php $__env->startSection('title','İlan'); ?>
<?php echo $__env->make('front.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<!--/ Contact Star /-->
<section class="contact">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 section-t8">
          <div class="row">
            <div class="col-md-7">
              <form class="form-a contactForm" action="" method="post" role="form" enctype="multipart/form-data">
                <div id="sendmessage">Your message has been sent. Thank you!</div>
                <div id="errormessage">bir hata var aman dikkat</div>
                <div class="row">
                  <div class="col-md-12 mb-3">
                    <div class="form-group">
                      <label>İlan Başlığı</label>
                        <input type="url" name="advtitle" class="form-control form-control-lg form-control-a" placeholder="İlan Başlığını Giriniz" data-rule="minlen:3" data-msg="Başlık en az 3 karakter olmalıdır!">
                        <div class="validation"></div>
                    </div>
                  </div>
                  <div class="col-md-12 mb-3">
                    <div class="form-group">
                    <label>Fiyat</label>
                      <input type="url" name="advcost" class="form-control form-control-lg form-control-a" placeholder="Fiyat" data-rule="minlen:1" data-msg="Lütfen Fiyat Giriniz!">
                      <div class="validation"></div>
                    </div>
                  </div>
                  <div class="col-md-12 mb-3">
                    <div class="form-group">
                    <label for="state">Durum</label>
                    <select class="form-control form-control-lg form-control-a" id="state">
                        <option>Satılık</option>
                        <option>Kiralık</option>
                        <option>Günübirlik Kiralık</option>
                    </select>
                    <div class="validation"></div>
                    </div>
                    </div>
                    <div class="col-md-12 mb-3">
                      <div class="form-group">
                      <label for="type">Tip</label>
                      <select class="form-control form-control-lg form-control-a" id="type">
                          <option>Ev</option>
                          <option>Dükkan</option>
                          <option>Arsa</option>
                      </select>
                      <div class="validation"></div>
                      </div>
                    </div>
                  <div class="col-md-12 mb-3">
                    <div class="form-group">
                    <label>Alan</label>
                      <input type="url" name="advzone" class="form-control form-control-lg form-control-a" placeholder="Alan" data-rule="minlen:1" data-msg="Lütfen Alan Giriniz!">
                      <div class="validation"></div>
                    </div>
                  </div>
                  <div class="col-md-12 mb-3">
                    <div class="form-group">
                    <label for="room">Oda Sayısı</label>
                    <select class="form-control form-control-lg form-control-a" id="room">
                        <option>1+0</option>
                        <option>1+1</option>
                        <option>2+0</option>
                        <option>2+1</option>
                        <option>3+0</option>
                        <option>3+1</option>
                        <option>4+1</option>
                    </select>
                    <div class="validation"></div>
                    </div>
                    </div>
                    <div class="col-md-12 mb-3">
                    <div class="form-group">
                    <label for="floor">Kat</label>
                    <select class="form-control form-control-lg form-control-a" id="floor">
                        <option>1</option>
                        <option>2</option>
                        <option>3</option>
                    </select>
                    <div class="validation"></div>
                    </div>
                    </div>
                    <div class="col-md-12 mb-3">
                    <div class="form-group">
                    <label for="image">Resim Seç</label>
                        <input class="form-control form-control-lg form-control-a" type="file" id="images" name="images" multiple accept="image/png, image/jpeg, image/jpg" require>
                        <div class="validation"></div>
                    </div>
                    </div>
                    <div class="col-md-12 mb-3">
                    <div class="form-group">
                    <label for="floor">İl</label>
                    <select class="form-control form-control-lg form-control-a" id="il" onchange="getIlId()">
                    <option value="0">İl seçiniz</option>
                    <?php $__currentLoopData = $iller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $il): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($il->id); ?>"><?php echo e($il->il); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="validation"></div>
                    </div>
                    </div>
                    <div class="col-md-12 mb-3">
                    <div class="form-group">
                    <label for="floor">İlçe</label>
                    <select class="form-control form-control-lg form-control-a" id="ilce" onchange="getIlceId()">
                        <option value="0">İlçe seçiniz</option>
                    </select>
                    <div class="validation"></div>
                    </div>
                    </div>
                    <div class="col-md-12 mb-3">
                    <div class="form-group">
                    <label for="floor">Mahalle</label>
                    <select class="form-control form-control-lg form-control-a" id="mah">
                        <option value="0">Mahalle seçiniz</option>
                    </select>
                    <div class="validation"></div>
                    </div>
                    </div>
                    <div class="col-md-12 mb-3">
                    <div class="form-group">
                        <label>Adres</label>
                        <input type="url" name="advaddress" class="form-control form-control-lg form-control-a" placeholder="Adresinizi Giriniz" data-rule="minlen:3" data-msg="Adres en az 3 karakter olmalıdır!">
                        <div class="validation"></div>
                        </div>
                    </div> 
                    <div class="col-md-12 mb-3">
                  <div class="form-group">
                    <label>Telefon</label>
                      <input type="url" name="advphone" class="form-control form-control-lg form-control-a" placeholder="İlan Başlığını Giriniz" data-rule="minlen:11" data-msg="Telefon!">
                      <div class="validation"></div>
                    </div>
                  </div>
                  <div class="col-md-12 mb-3">
                  <div class="form-group">
                      <label>Açıklama</label>
                        <textarea name="advtext" class="form-control" name="message" cols="45" rows="6" data-rule="required" data-msg="Lütfen açıklama giriniz!" placeholder="Açıklama"></textarea>
                        <div class="validation"></div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <button type="submit" class="btn btn-a">İlan Ver</button>
                  </div>
                </div>
              </form>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--/ Contact End /-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://code.jquery.com/jquery-3.6.1.milerigetirn.js"></script>
<script>
  function getIlId(){
    $('#ilce').find('option').remove().end();
    var il = document.getElementById('il').value;
    //console.log(il);
    $.ajax({
      type:"get",
      url:'adres/il_id='+il,
      success:function(data){
      data.forEach(getIlce);
      //document.getElementById('ilce').value=data
    }
  });
  }
  
  function getIlce(item){
    //console.log(item+"/"+x.ilce);
    var opt = document.createElement("option");
    document.getElementById('ilce').options.add(opt);
    opt.text = item.ilce;
    opt.value = item.id;
  }

  function getIlceId(){
    $('#mah').find('option').remove().end();
    var ilce = document.getElementById('ilce').value;
    //console.log(il);
    $.ajax({
      type:"get",
      url:'adres/ilce_id='+ilce,
      success:function(data){
      data.forEach(getMah);
      //document.getElementById('ilce').value=data
    }
  });
  }

  function getMah(item){
    var opt = document.createElement("option");
    document.getElementById('mah').options.add(opt);
    opt.text = item.mahalle;
    opt.value = item.id;
  }

 
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\umut\Desktop\emlak sitesi\emlak\resources\views/front/advpage.blade.php ENDPATH**/ ?>