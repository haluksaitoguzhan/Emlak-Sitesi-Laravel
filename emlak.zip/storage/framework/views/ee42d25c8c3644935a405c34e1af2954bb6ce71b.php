<!--
Author: Colorlib
Author URL: https://colorlib.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Emlak Giriş</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="<?php echo e(asset('register_login')); ?>/css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">
<!-- //web font -->
</head>
<body>
<!-- <div class="agileits-top col-md-12">
<span><p>Admin olarak giriş yap <a href="<?php echo e(route('admin_giris')); ?>"> Giriş Yap</a></p></span>
</div> -->
<div class="myclass">
	<span><p>Admin olarak giriş yap  <a class="white-input" href="<?php echo e(route('admin_giris')); ?>">  Giriş Yap?</a></p></span>
</div>

	<!-- main -->
	<div class="main-w3layouts wrapper">
		<h1>Giriş Yap</h1>
		<div class="main-agileinfo">
			<div class="agileits-top">
				<?php if($errors->any()): ?>
				<div class="alert alert-danger">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				<?php endif; ?>
				<form action="<?php echo e(route('my_login_post')); ?>" method="post">
                    <?php echo csrf_field(); ?>
					<input class="text email" type="email" name="email" placeholder="Email" required="">
					<input class="text" type="password" name="password" placeholder="Şifre" required="">
					<div class="wthree-text">
						<div class="clear"> </div>
					</div>
					<input type="submit" value="GİRİŞ YAP">
				</form>
				<p>Mevcut hesabın yok mu? <a href="<?php echo e(route('my_register_post')); ?>"> Kaydol</a></p><br>
				
			</div>
		</div>
		<!-- copyright -->
		<!-- //copyright -->
		<ul class="colorlib-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
	<!-- //main -->
</body>
</html><?php /**PATH C:\Users\umut\Desktop\emlak\resources\views/front/login.blade.php ENDPATH**/ ?>